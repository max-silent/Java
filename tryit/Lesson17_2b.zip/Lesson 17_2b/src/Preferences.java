public interface Preferences {
	public String[] colorList = {"Red", "Green", "Blue", "Cyan", "Magenta", "Yellow", "Black"};
	public String[] fontList = {"Arial", "Times New Roman", "Helvetica"};
	public String[] fontSizeList = {"12", "18", "25", "40", "64"};
	//public Integer[] fontSizeList = {12, 18, 25, 40, 64};

}
