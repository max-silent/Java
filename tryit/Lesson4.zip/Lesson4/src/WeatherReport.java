class WeatherReport{
      static double convertToCelsius(double far){
           return ((far - 32) * 5 / 9);
    }   
} 
