class Tax2 {
    double grossIncome; // class member variables
    String state;
    int dependents;
   
    // Constructor
    Tax2 (double grossIncome, String state, int dependents){
       this.grossIncome = grossIncome;  // instance variable initialization
       this.state = state;
       this.dependents=dependents;
    }
}
