class Tax4 {
    double grossIncome; // class member variables
    String state;
    int dependents;
    static int customerCounter;
   
    // Constructor
    Tax4 (double gi, String st, int depen){
       grossIncome = gi;  // member variable initialization
       state = st;
       dependents=depen;
       customerCounter++;   // increment the counter by one
    }
}
