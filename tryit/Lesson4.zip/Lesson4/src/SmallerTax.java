class SmallerTax extends Tax1{   
    // Constructor
    SmallerTax (double gi, String st, int depen){
       super(gi,st,depen);
       System.out.println("Applying special tax rates for my friends."); 
    }
}
