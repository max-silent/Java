class TestTax{
     public static void main(String[] args){
            double grossIncome; // local variables
            String state;
            int dependents;
         
            grossIncome= 50000; 
            dependents= 2;
            state= "NJ";

            Tax3 t = new Tax3(grossIncome, state, dependents); 

            double yourTax = t.calcTax(); //calculating tax 
                            
           // Printing the result 
           System.out.println("Your tax is " + yourTax);
     } 
 }
