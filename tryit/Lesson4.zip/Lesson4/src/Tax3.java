class Tax3 {
    double grossIncome; // class member variables
    String state;
    int dependents;
   
    // First Constructor
    Tax3 (double grossIncome, String state, int dependents){
       this.grossIncome = grossIncome;  // instance variable initialization
       this.state = state;
       this.dependents=dependents;
    }

   // Second Constructor
    Tax3 (double grossIncome, int dependents){
       this(grossIncome, "NY", dependents); 
    }

    // The method calcTax() is taken from the Try It section of Lesson 3
    public double calcTax() {         
        double  stateTax=0;
        if (grossIncome < 30000) {
          stateTax=grossIncome*0.05;
        }
        else{
          stateTax= grossIncome*0.06;
        } 
          return stateTax;
  }

}
