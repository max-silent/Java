class Tax1 {
    double grossIncome; // class variables
    String state;
    int dependents;
   
    // Constructor
    Tax1 (double gi, String st, int depen){
       grossIncome = gi;  // class variable initialization
       state = st;
       dependents=depen;
    }
}
