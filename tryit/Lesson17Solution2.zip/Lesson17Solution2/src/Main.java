import com.practicaljava.lesson17.game.TicTacToeGUI;
import com.practicaljava.lesson17.preferences.Preferences;
import com.practicaljava.lesson17.preferences.UserPreferences;

public class Main implements Preferences {

	public static void main(String[] args) {
		UserPreferences uPref = new UserPreferences();

		new TicTacToeGUI(uPref);
	}
}
