package com.practicaljava.lesson17.preferences;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class UserPreferences implements Serializable, Preferences {

	private static final long serialVersionUID = -8402611325744957495L;

	String gVersion;
	String gSkin;
	String gFont;

	public UserPreferences() {

		File f = new File("AppPreferences.ser");
		if (f.exists()) {
			readPreferencesFromFile();

		} else {
			// if no file found - we create a new one
			this.gVersion = gameVersion[0];
			this.gSkin = gameSkin[0];
			writePreferencesToFile();

		}

	}

	public void writePreferencesToFile() {
		FileOutputStream fOut = null;
		ObjectOutputStream oOut = null;
		try {
			fOut = new FileOutputStream("AppPreferences.ser");
			oOut = new ObjectOutputStream(fOut);
			oOut.writeObject(this);
			// serializing employee
		} catch (IOException e) {
			// close the streams
			try {
				oOut.flush();
				oOut.close();
				fOut.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();

			}
		}
		// System.out.println("The Preference object has been serialized into" +
		// "AppPreferences.ser");
	}

	public void readPreferencesFromFile() {

		FileInputStream fIn = null;
		ObjectInputStream oIn = null;
		try {
			fIn = new FileInputStream("AppPreferences.ser");
			oIn = new ObjectInputStream(fIn);
			UserPreferences tempUP = (UserPreferences) oIn.readObject();
			this.gVersion = tempUP.gVersion;
			this.gSkin = tempUP.gSkin;
			this.gFont = tempUP.gFont;
		} catch (ClassNotFoundException cnf) {
			cnf.printStackTrace();
		} catch (IOException e) {
			// close the streams
			try {
				oIn.close();
				fIn.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();

			}
		}

	}

	public String getgVersion() {
		return gVersion;
	}

	public void setgVersion(String gVersion) {
		this.gVersion = gVersion;
	}

	public String getgSkin() {
		return gSkin;
	}

	public void setgSkin(String gSkin) {
		this.gSkin = gSkin;
	}

	public String getgFont() {
		return gFont;
	}

	public void setgFont(String gFont) {
		this.gFont = gFont;
	}

}
