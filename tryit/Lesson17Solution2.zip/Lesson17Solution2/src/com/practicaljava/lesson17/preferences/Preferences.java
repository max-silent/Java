package com.practicaljava.lesson17.preferences;

public interface Preferences {

	public String[] gameVersion = { "Classic", "Cats vs. Dogs" };
	public String[] gameSkin = { "Bright", "Dark" };

}
