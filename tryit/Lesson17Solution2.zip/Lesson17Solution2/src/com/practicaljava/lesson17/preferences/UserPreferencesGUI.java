package com.practicaljava.lesson17.preferences;

import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class UserPreferencesGUI extends JPanel implements Preferences {

	JLabel gameVersionLabel = new JLabel("Version:");
	JLabel gameSkinLabel = new JLabel("Skin:");
	JLabel gameFontLabel = new JLabel("Font:");

	public JComboBox gameVersionCombo = new JComboBox(gameVersion);
	public JComboBox gameSkinCombo = new JComboBox(gameSkin);

	public UserPreferencesGUI() {

		UserPreferences uPref = new UserPreferences();
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		Box b1 = Box.createHorizontalBox();
		b1.add(gameVersionLabel);
		b1.add(Box.createHorizontalGlue());

		this.add(b1);
		this.add(Box.createHorizontalGlue());
		this.add(Box.createRigidArea(new Dimension(0, 10)));
		this.add(gameVersionCombo);
		gameVersionCombo.setSelectedItem(uPref.getgVersion());
		this.add(Box.createRigidArea(new Dimension(0, 25)));

		Box b2 = Box.createHorizontalBox();
		b2.add(gameSkinLabel);
		b2.add(Box.createHorizontalGlue());

		this.add(b2);
		this.add(Box.createRigidArea(new Dimension(0, 10)));
		this.add(gameSkinCombo);
		gameSkinCombo.setSelectedItem(uPref.getgSkin());
		this.add(Box.createRigidArea(new Dimension(0, 25)));

		Box b3 = Box.createHorizontalBox();
		b3.add(gameFontLabel);
		b3.add(Box.createHorizontalGlue());

	}
}
