package com.practicaljava.lesson17.game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.Toolkit;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

import com.practicaljava.lesson17.preferences.UserPreferences;

public class TicTacToeGUI extends JFrame {
	/**
	 * added serialVersionUID value
	 */
	private static final long serialVersionUID = 8531081473405506995L;
	static final String PLAYERX = "Player X";
	static final String PLAYERO = "Player O";

	private static final int BORDER = 1;
	private static final Color BORDER_COLOR = Color.orange;

	String playerName = PLAYERX;

	private boolean onePlayerMode = true;

	private String level = "Easy";

	TButton[][] buttons = new TButton[3][3];
	private JButton resetButton = new JButton("Play Again");

	private JButton prefButton = new JButton("Preferences");

	ButtonGroup oneTwoGroup = new ButtonGroup();

	ButtonGroup gameLevelGroup = new ButtonGroup();

	JLabel playerNumber;
	private Panel generalPanel;
	private Panel buttonsPanel;
	private Panel buttonsAndStatusPanel;
	private Panel menuPanel;
	private Panel gameLevelPanel;

	boolean tttEnabled = true;

	private int turn = 0;

	private String cellImageX;
	private String cellImageO;

	private String skinColor;

	private String fontName;

	JRadioButton option1;
	JRadioButton option2;
	JRadioButton optionEasy;
	JRadioButton optionHard;

	public TicTacToeGUI(UserPreferences uPref) {

		if (uPref.getgVersion().equals("Classic")) {
			cellImageX = "X";
			cellImageO = "O";
		} else {
			cellImageX = "Cat";
			cellImageO = "Dog";

		}

		Color bgColor;

		if (uPref.getgSkin().equals("Bright")) {

			bgColor = new Color(239, 237, 223);

		} else {

			bgColor = new Color(183, 193, 199);
		}

		TicTacToeEngine tttEngine = new TicTacToeEngine(this);

		generalPanel = new Panel();
		menuPanel = new Panel();
		gameLevelPanel = new Panel();
		menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));

		gameLevelPanel.setLayout(new GridLayout(2, 2, -70, 0));

		generalPanel.setBackground(bgColor);

		option1 = new JRadioButton("1 Player", true);
		option1.setFont(new Font("Forte", Font.PLAIN, 22));
		option1.setBackground(bgColor);
		option1.addActionListener(tttEngine);

		option2 = new JRadioButton("2 Players", false);
		option2.setFont(new Font("Forte", Font.PLAIN, 22));
		option2.setBackground(bgColor);
		option2.addActionListener(tttEngine);

		optionEasy = new JRadioButton("Easy", true);
		optionEasy.setBackground(bgColor);
		optionEasy.setFont(new Font("Calibri", Font.PLAIN, 14));
		optionHard = new JRadioButton("Hard", false);
		optionHard.setBackground(bgColor);
		optionHard.setFont(new Font("Calibri", Font.PLAIN, 14));
		optionEasy.addActionListener(tttEngine);

		optionHard.addActionListener(tttEngine);

		oneTwoGroup.add(option1);
		oneTwoGroup.add(option2);

		gameLevelGroup.add(optionEasy);
		gameLevelGroup.add(optionHard);

		Box gameLevelBox = new Box(BoxLayout.X_AXIS);

		gameLevelBox.add(option1);
		gameLevelBox.add(option2);

		menuPanel.add(option1);

		gameLevelPanel.add(new JLabel(""));
		gameLevelPanel.add(optionEasy);
		gameLevelPanel.add(new JLabel(""));
		gameLevelPanel.add(optionHard);

		menuPanel.add(gameLevelPanel);
		menuPanel.add(Box.createRigidArea(new Dimension(0, 10)));
		menuPanel.add(option2);
		menuPanel.add(Box.createRigidArea(new Dimension(0, 10)));
		menuPanel.add(resetButton);
		menuPanel.add(Box.createRigidArea(new Dimension(0, 50)));
		menuPanel.add(prefButton);

		buttonsPanel = new Panel();
		playerNumber = new JLabel(playerName);

		playerNumber.setFont(new Font("Helvetica Neue", Font.PLAIN, 22));

		// playerNumber.setBackground(Color.CYAN);
		playerNumber.setPreferredSize(new Dimension(400, 50));
		playerNumber.setVerticalAlignment(JLabel.CENTER);
		playerNumber.setHorizontalAlignment(JLabel.CENTER);

		buttonsPanel.setLayout(new GridLayout(3, 3));

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				buttons[i][j] = new TButton();
				buttons[i][j].addMouseListener(tttEngine);
				buttons[i][j].setTicValue("");
				buttons[i][j].setBackground(new Color(255, 255, 255));
				buttons[i][j].setFocusable(false);

				if (i == 0 && j == 0) {
					buttons[i][j].setBorder(BorderFactory.createMatteBorder(0, 0, BORDER, BORDER,
							BORDER_COLOR));
				}
				if (i == 0 && j == 1) {
					buttons[i][j].setBorder(BorderFactory.createMatteBorder(0, 0, BORDER, BORDER,
							BORDER_COLOR));
				}
				if (i == 0 && j == 2) {
					buttons[i][j].setBorder(BorderFactory.createMatteBorder(0, 0, BORDER, 0,
							BORDER_COLOR));
				}
				if (i == 1 && j == 0) {
					buttons[i][j].setBorder(BorderFactory.createMatteBorder(0, 0, BORDER, BORDER,
							BORDER_COLOR));
				}
				if (i == 1 && j == 1) {
					buttons[i][j].setBorder(BorderFactory.createMatteBorder(0, 0, BORDER, BORDER,
							BORDER_COLOR));
				}
				if (i == 1 && j == 2) {
					buttons[i][j].setBorder(BorderFactory.createMatteBorder(0, 0, BORDER, 0,
							BORDER_COLOR));
				}
				if (i == 2 && j == 0) {
					buttons[i][j].setBorder(BorderFactory.createMatteBorder(0, 0, 0, BORDER,
							BORDER_COLOR));
				}
				if (i == 2 && j == 1) {
					buttons[i][j].setBorder(BorderFactory.createMatteBorder(0, 0, 0, BORDER,
							BORDER_COLOR));
				}
				if (i == 2 && j == 2) {
					buttons[i][j].setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0,
							BORDER_COLOR));
				}

				buttonsPanel.add(buttons[i][j]);
			}
		}

		tttEngine.setPlayerName(PLAYERX);
		resetButton.addMouseListener(tttEngine);
		prefButton.addMouseListener(tttEngine);

		buttonsAndStatusPanel = new Panel();
		BoxLayout bBoxLayout = new BoxLayout(buttonsAndStatusPanel, BoxLayout.Y_AXIS);

		buttonsAndStatusPanel.setLayout(bBoxLayout);
		buttonsAndStatusPanel.setPreferredSize(new Dimension(350, 350));

		Box lineBox = new Box(BoxLayout.LINE_AXIS);
		lineBox.add(playerNumber);
		buttonsAndStatusPanel.add(buttonsPanel);
		buttonsAndStatusPanel.add(lineBox);

		generalPanel.add(buttonsAndStatusPanel, BorderLayout.CENTER);
		generalPanel.add(menuPanel, BorderLayout.WEST);

		add(generalPanel);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int) screenSize.getWidth() / 4, (int) screenSize.getHeight() / 6);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setSize(600, 460);
		setVisible(true);

	}

	public int getTurn() {
		return turn;
	}

	public void setTurn(int turn) {
		this.turn = turn;
	}

	public void enableGameLevels(boolean enableFlag) {

		if (enableFlag) {
			gameLevelPanel.setEnabled(true);

			for (Enumeration<AbstractButton> buttons = gameLevelGroup.getElements(); buttons
					.hasMoreElements();) {
				AbstractButton button = buttons.nextElement();
				button.setForeground(Color.DARK_GRAY);
			}

			gameLevelPanel.repaint();
		} else {
			gameLevelPanel.setEnabled(false);

			for (Enumeration<AbstractButton> buttons = gameLevelGroup.getElements(); buttons
					.hasMoreElements();) {
				AbstractButton button = buttons.nextElement();
				button.setForeground(Color.GRAY);
			}

			gameLevelPanel.repaint();
		}
	}

	public boolean isOnePlayerMode() {
		return onePlayerMode;
	}

	public void setOnePlayerMode(boolean onePlayerMode) {
		this.onePlayerMode = onePlayerMode;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getCellImageX() {
		return cellImageX;
	}

	public void setCellImage(String gameVersion) {
		if (gameVersion.equals("Classic")) {
			this.cellImageX = "X";
			this.cellImageO = "O";
		} else {
			this.cellImageX = "Cat";
			this.cellImageO = "Dog";
		}

	}

	public void setSkin(String gameSkin) {
		Color bgColor;
		if (gameSkin.equals("Bright")) {
			bgColor = new Color(239, 237, 223);
		} else {
			bgColor = new Color(183, 193, 199);
		}

		this.generalPanel.setBackground(bgColor);
		this.gameLevelPanel.setBackground(bgColor);
		this.menuPanel.setBackground(bgColor);
		this.buttonsPanel.setBackground(bgColor);
		this.buttonsAndStatusPanel.setBackground(bgColor);
		this.playerNumber.setBackground(bgColor);
		this.option1.setBackground(bgColor);
		this.option2.setBackground(bgColor);
		this.optionEasy.setBackground(bgColor);
		this.optionHard.setBackground(bgColor);

		this.repaint();

	}

	public void setCellImageX(String cellImageX) {
		this.cellImageX = cellImageX;
	}

	public String getCellImageO() {
		return cellImageO;
	}

	public void setCellImageO(String cellImageO) {
		this.cellImageO = cellImageO;
	}

	public String getSkinColor() {
		return skinColor;
	}

	public void setSkinColor(String skinColor) {
		this.skinColor = skinColor;
	}

	public String getFontName() {
		return fontName;
	}

	public void setFontName(String fontName) {
		this.fontName = fontName;
	}

}