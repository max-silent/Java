package com.practicaljava.lesson17.game;

import javax.swing.JButton;

// Tic Tac Toe Button that stores tic value, not to use text value of the button

public class TButton extends JButton {

	private static final long serialVersionUID = 2891311810723008008L;
	private String ticValue;

	public String getTicValue() {
		return ticValue;
	}

	public void setTicValue(String ticValue) {
		this.ticValue = ticValue;
	}

}
