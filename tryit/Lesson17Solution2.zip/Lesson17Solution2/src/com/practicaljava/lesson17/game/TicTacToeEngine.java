package com.practicaljava.lesson17.game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

import com.practicaljava.lesson17.preferences.UserPreferences;
import com.practicaljava.lesson17.preferences.UserPreferencesGUI;

public class TicTacToeEngine extends MouseAdapter implements MouseListener, ActionListener {

	TicTacToeGUI tttApplet;

	public TicTacToeEngine(TicTacToeGUI tttApplet) {
		this.tttApplet = tttApplet;
	}

	@Override
	public void mousePressed(MouseEvent e) {

		String nextTicType = "";
		JButton currentButton = (JButton) e.getComponent();

		// Clear the Tic Tac Toe table if "Play Again" clicked
		if (currentButton.getText() == "Play Again") {

			if ((tttApplet.tttEnabled) && (tttApplet.getTurn() != 9)) {
				int reply = JOptionPane.showConfirmDialog(null,
						"Still playing. Are you sure to reset?", "Are you sure to reset?",
						JOptionPane.YES_NO_OPTION);
				if (reply == JOptionPane.YES_OPTION) {
					reset();
				}
			} else {
				reset();
			}

			tttApplet.tttEnabled = true;
			// processing Preferences button
		} else if (currentButton.getText() == "Preferences") {

			String settingsArray[] = { "Save settings", "Cancel" };
			UserPreferencesGUI prefGUI = new UserPreferencesGUI();

			int i = (int) JOptionPane.showOptionDialog(tttApplet, prefGUI, "Settings",
					JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
					settingsArray, settingsArray[0]);

			if (i == JOptionPane.YES_OPTION) {

				UserPreferences tempUP = new UserPreferences();
				tempUP.setgVersion(prefGUI.gameVersionCombo.getSelectedItem().toString());
				tempUP.setgSkin(prefGUI.gameSkinCombo.getSelectedItem().toString());

				// apply changes
				tttApplet.setCellImage(prefGUI.gameVersionCombo.getSelectedItem().toString());
				tttApplet.setSkin(prefGUI.gameSkinCombo.getSelectedItem().toString());

				tempUP.writePreferencesToFile();

			}
		}

		else if (tttApplet.tttEnabled) {

			if (((TButton) currentButton).getTicValue() == "") {

				tttApplet.setTurn(tttApplet.getTurn() + 1);

				if (tttApplet.playerName == TicTacToeGUI.PLAYERX) {
					((TButton) currentButton).setTicValue("X");
					currentButton.setIcon(createImageIcon("/images/" + tttApplet.getCellImageX()
							+ ".png", ""));
					setPlayerName(TicTacToeGUI.PLAYERO);
					nextTicType = "O";
				} else if (tttApplet.playerName == TicTacToeGUI.PLAYERO) {
					((TButton) currentButton).setTicValue("O");
					currentButton.setIcon(createImageIcon("/images/" + tttApplet.getCellImageO()
							+ ".png", ""));
					setPlayerName(TicTacToeGUI.PLAYERX);
					nextTicType = "X";
				}

				checkForWinner();

				if (tttApplet.isOnePlayerMode()) {
					if (tttApplet.getTurn() % 2 == 1 && tttApplet.getTurn() < 8) {
						if (tttApplet.getLevel().equals("Easy")) {
							easyBotClick();
						} else {
							this.hardBotClick(nextTicType);
						}
					}
				}

			}

		}
	}

	/* Processing Radio buttons */

	public void actionPerformed(ActionEvent e) {
		JRadioButton jb = (JRadioButton) e.getSource();
		// jb.setBackground(Color.BLUE);
		if (jb.getText() == "2 Players") {
			tttApplet.enableGameLevels(false);
			tttApplet.setOnePlayerMode(false);
		}
		if (jb.getText() == "1 Player") {
			tttApplet.enableGameLevels(true);
			tttApplet.setOnePlayerMode(true);
		}

		if (jb.getText() == "Easy") {
			tttApplet.setLevel("Easy");
			// System.out.println("Easy bot enabled");
		}

		if (jb.getText() == "Hard") {
			tttApplet.setLevel("Hard");
			// System.out.println("Hard bot enabled");
		}

	}

	private boolean findThreeInARow() {
		boolean threeFound = false;
		String cellType = "";
		Point firstCell = new Point();
		Point secondCell = new Point();
		Point thirdCell = new Point();

		// searching rows
		for (int i = 0; i < 3; i++) {

			if (tttApplet.buttons[i][0].getTicValue() == tttApplet.buttons[i][1].getTicValue()
					&& tttApplet.buttons[i][1].getTicValue() == tttApplet.buttons[i][2]
							.getTicValue() && tttApplet.buttons[i][0].getTicValue() != "") {
				firstCell.x = i;
				firstCell.y = 0;
				secondCell.x = i;
				secondCell.y = 1;
				thirdCell.x = i;
				thirdCell.y = 2;

				threeFound = true;
				cellType = tttApplet.buttons[i][0].getTicValue();
			}
		}

		// searching columns
		for (int i = 0; i < 3; i++) {

			if (tttApplet.buttons[0][i].getTicValue() == tttApplet.buttons[1][i].getTicValue()
					&& tttApplet.buttons[1][i].getTicValue() == tttApplet.buttons[2][i]
							.getTicValue() && tttApplet.buttons[0][i].getTicValue() != "") {

				firstCell.x = 0;
				firstCell.y = i;
				secondCell.x = 1;
				secondCell.y = i;
				thirdCell.x = 2;
				thirdCell.y = i;

				threeFound = true;

				cellType = tttApplet.buttons[0][i].getTicValue();
			}
		}
		// searching left upper to right bottom diagonal
		if (tttApplet.buttons[0][0].getTicValue() == tttApplet.buttons[1][1].getTicValue()
				&& tttApplet.buttons[1][1].getTicValue() == tttApplet.buttons[2][2].getTicValue()
				&& tttApplet.buttons[0][0].getTicValue() != "") {
			threeFound = true;
			firstCell.x = 0;
			firstCell.y = 0;
			secondCell.x = 1;
			secondCell.y = 1;
			thirdCell.x = 2;
			thirdCell.y = 2;
			cellType = tttApplet.buttons[0][0].getTicValue();

		}
		// searching left upper to right bottom diagonal
		if (tttApplet.buttons[0][2].getTicValue() == tttApplet.buttons[1][1].getTicValue()
				&& tttApplet.buttons[1][1].getTicValue() == tttApplet.buttons[2][0].getTicValue()
				&& tttApplet.buttons[0][2].getTicValue() != "") {

			threeFound = true;
			firstCell.x = 0;
			firstCell.y = 2;
			secondCell.x = 1;
			secondCell.y = 1;
			thirdCell.x = 2;
			thirdCell.y = 0;
			cellType = tttApplet.buttons[0][2].getTicValue();

		}

		if (threeFound) {
			tttApplet.tttEnabled = false;
			colorWinner(firstCell, secondCell, thirdCell, cellType);
		}
		return threeFound;
	}

	public void checkForWinner() {

		if (findThreeInARow()) {
			String winnerName = (tttApplet.playerName == TicTacToeGUI.PLAYERX) ? tttApplet
					.getCellImageO() : tttApplet.getCellImageX();

			if (winnerName.equals("Dog") || winnerName.equals("Cat")) {
				winnerName = "The " + winnerName;
			}

			tttApplet.playerNumber.setText(winnerName.concat(" won!!! "));
			tttApplet.playerNumber.setFont(new Font("Forte", Font.PLAIN, 36));
			tttApplet.playerNumber
					.setForeground(tttApplet.playerName == TicTacToeGUI.PLAYERX ? new Color(82, 87,
							137) : new Color(192, 60, 21));
		} else if (tttApplet.getTurn() == 9) {
			tttApplet.playerNumber.setFont(new Font("Forte", Font.PLAIN, 36));
			tttApplet.playerNumber.setText("Tie!");
		}

	}

	void setPlayerName(String playerName) {
		tttApplet.playerNumber.setFont(new Font("Forte", Font.PLAIN, 28));
		tttApplet.playerNumber.setForeground(new Color(95, 109, 103));
		tttApplet.playerName = playerName;
		if (tttApplet.getCellImageO().length() > 1 && playerName.endsWith("O")) {
			tttApplet.playerNumber.setText("Hey Dog, your turn! ");
		} else if (tttApplet.getCellImageO().length() > 1 && playerName.endsWith("X")) {
			tttApplet.playerNumber.setText("Hey Cat, your turn! ");
		} else {

			tttApplet.playerNumber.setText(playerName + ", your turn! ");

		}
	}

	/* Reset the game board */
	private void reset() {
		for (TButton[] jb : tttApplet.buttons) {
			for (TButton jbInner : jb) {

				jbInner.setTicValue("");
				jbInner.setIcon(null);
				jbInner.setBackground(Color.WHITE);
			}

			tttApplet.repaint();
		}
		setPlayerName(TicTacToeGUI.PLAYERX);
		tttApplet.setTurn(0);
	}

	/* Color 3 in a row by yellow color */
	private void colorWinner(Point firstCell, Point secondCell, Point thirdCell, String cellType) {
		Color winColor = new Color(248, 212, 110);
		tttApplet.buttons[firstCell.x][firstCell.y].setBackground(winColor);
		tttApplet.buttons[secondCell.x][secondCell.y].setBackground(winColor);
		tttApplet.buttons[thirdCell.x][thirdCell.y].setBackground(winColor);

	}

	public void easyBotClick() {
		Random randomNum = new Random();
		int randomCellX = randomNum.nextInt(3);
		int randomCellY = randomNum.nextInt(3);

		while (tttApplet.buttons[randomCellX][randomCellY].getTicValue().length() != 0) {

			randomCellX = randomNum.nextInt(3);
			randomCellY = randomNum.nextInt(3);

		}

		MouseEvent me = new MouseEvent(tttApplet.buttons[randomCellX][randomCellY],
				MouseEvent.MOUSE_PRESSED, 1, 0, 1, 1, 1, false);
		tttApplet.buttons[randomCellX][randomCellY].dispatchEvent(me);
		// System.out.println("easyBotClick: " + randomCellX + "," +
		// randomCellY);

	}

	public void hardBotClick(String ticType) {

		String opponentsType = ticType.equals("X") ? "O" : "X";

		/*
		 * Rule #1. If Player can win immediately - he wins by putting 3rd in a
		 * row.
		 * 
		 * Searching for the sequence of 2 of the ticType (X or O)
		 */

		Point thirdOfBot = new Point();
		thirdOfBot.x = -1;
		thirdOfBot = findThird(ticType);

		if (thirdOfBot.x != -1) {
			MouseEvent me = new MouseEvent(tttApplet.buttons[thirdOfBot.x][thirdOfBot.y],
					MouseEvent.MOUSE_PRESSED, 1, 0, 1, 1, 1, false);
			tttApplet.buttons[thirdOfBot.x][thirdOfBot.y].dispatchEvent(me);
			// System.out.println("thirdOfBot: " + thirdOfBot.x + "," +
			// thirdOfBot.y);
			return;
		}

		/*
		 * Rule #2. If Player cannot win now, but can prevent opponent from win
		 * by clicking cell where opponent will click for 3 in a row - he does
		 * this.
		 */

		Point thirdOfOpponent = new Point();
		thirdOfOpponent.x = -1;
		thirdOfOpponent = findThird(opponentsType);

		if (thirdOfOpponent.x != -1) {
			MouseEvent me = new MouseEvent(tttApplet.buttons[thirdOfOpponent.x][thirdOfOpponent.y],
					MouseEvent.MOUSE_PRESSED, 1, 0, 1, 1, 1, false);
			tttApplet.buttons[thirdOfOpponent.x][thirdOfOpponent.y].dispatchEvent(me);
			// System.out.println("thirdOfOpponent: " + thirdOfOpponent.x + ","
			// + thirdOfOpponent.y);
			return;
		}

		/* Rule #3. If we can click central cell - we do it */

		if (tttApplet.buttons[1][1].getTicValue().equals("")) {
			MouseEvent me = new MouseEvent(tttApplet.buttons[1][1], MouseEvent.MOUSE_PRESSED, 1, 0,
					1, 1, 1, false);
			tttApplet.buttons[1][1].dispatchEvent(me);
			// System.out.println("Click central: 1,1");
			return;
		}

		/*
		 * Rule #4. If central cell is occupied by opponent - we are trying to
		 * occupy corners
		 */

		if (tttApplet.buttons[1][1].getTicValue().equals(ticType.equals("X") ? "O" : "X")) {

			if (tttApplet.buttons[0][0].getTicValue().equals("")) {

				MouseEvent me = new MouseEvent(tttApplet.buttons[0][0], MouseEvent.MOUSE_PRESSED,
						1, 0, 1, 1, 1, false);
				tttApplet.buttons[0][0].dispatchEvent(me);
				// System.out.println("Click corner: 0, 0");
				return;
			}

			if (tttApplet.buttons[0][2].getTicValue().equals("")) {

				MouseEvent me = new MouseEvent(tttApplet.buttons[0][2], MouseEvent.MOUSE_PRESSED,
						1, 0, 1, 1, 1, false);
				tttApplet.buttons[0][0].dispatchEvent(me);
				// System.out.println("Click corner: 0, 2");
				return;
			}

			if (tttApplet.buttons[2][0].getTicValue().equals("")) {

				MouseEvent me = new MouseEvent(tttApplet.buttons[2][0], MouseEvent.MOUSE_PRESSED,
						1, 0, 1, 1, 1, false);
				tttApplet.buttons[2][0].dispatchEvent(me);
				// System.out.println("Click corner: 2, 0");
				return;
			}

			if (tttApplet.buttons[2][2].getTicValue().equals("")) {

				MouseEvent me = new MouseEvent(tttApplet.buttons[2][2], MouseEvent.MOUSE_PRESSED,
						1, 0, 1, 1, 1, false);
				tttApplet.buttons[2][2].dispatchEvent(me);
				// System.out.println("Click corner: 0, 0");
				return;
			}

		}

		/*
		 * Rule #5. In case any of 1-4 were not triggered - executing random
		 * click by the help of easy bot
		 */

		easyBotClick();

	}

	/* Find third cell for the given ticType */

	private Point findThird(String ticType) {

		Point nextCellClick = new Point();

		nextCellClick.x = -1;

		for (int i = 0; i < 3; i++) {

			// ==========================Checking rows to put 3rd in a row

			if (tttApplet.buttons[i][0].getTicValue() == tttApplet.buttons[i][1].getTicValue()
					&& tttApplet.buttons[i][0].getTicValue().equals(ticType)
					&& tttApplet.buttons[i][2].getTicValue().equals("")) {
				nextCellClick.x = i;
				nextCellClick.y = 2;
			}
			if (tttApplet.buttons[i][1].getTicValue() == tttApplet.buttons[i][2].getTicValue()
					&& tttApplet.buttons[i][1].getTicValue().equals(ticType)
					&& tttApplet.buttons[i][0].getTicValue().equals("")) {
				nextCellClick.x = i;
				nextCellClick.y = 0;
			}
			if (tttApplet.buttons[i][0].getTicValue() == tttApplet.buttons[i][2].getTicValue()
					&& tttApplet.buttons[i][0].getTicValue().equals(ticType)
					&& tttApplet.buttons[i][1].getTicValue().equals("")) {
				nextCellClick.x = i;
				nextCellClick.y = 1;
			}

			// ==========================Checking columns to put 3rd in a row

			if (tttApplet.buttons[0][i].getTicValue() == tttApplet.buttons[1][i].getTicValue()
					&& tttApplet.buttons[0][i].getTicValue().equals(ticType)
					&& tttApplet.buttons[2][i].getTicValue().equals("")) {
				nextCellClick.x = 2;
				nextCellClick.y = i;
			}
			if (tttApplet.buttons[1][i].getTicValue() == tttApplet.buttons[2][i].getTicValue()
					&& tttApplet.buttons[1][i].getTicValue().equals(ticType)
					&& tttApplet.buttons[0][i].getTicValue().equals("")) {
				nextCellClick.x = 0;
				nextCellClick.y = i;
			}
			if (tttApplet.buttons[0][i].getTicValue() == tttApplet.buttons[2][i].getTicValue()
					&& tttApplet.buttons[0][i].getTicValue().equals(ticType)
					&& tttApplet.buttons[1][i].getTicValue().equals("")) {
				nextCellClick.x = 1;
				nextCellClick.y = i;
			}
		}

		// ==Checking left top to right bottom diagonal to put 3rd in a row

		if (tttApplet.buttons[0][0].getTicValue() == tttApplet.buttons[1][1].getTicValue()
				&& tttApplet.buttons[0][0].getTicValue().equals(ticType)
				&& tttApplet.buttons[2][2].getTicValue().equals("")) {
			nextCellClick.x = 2;
			nextCellClick.y = 2;
		}
		if (tttApplet.buttons[1][1].getTicValue() == tttApplet.buttons[2][2].getTicValue()
				&& tttApplet.buttons[1][1].getTicValue().equals(ticType)
				&& tttApplet.buttons[0][0].getTicValue().equals("")) {
			nextCellClick.x = 0;
			nextCellClick.y = 0;
		}
		if (tttApplet.buttons[0][0].getTicValue() == tttApplet.buttons[2][2].getTicValue()
				&& tttApplet.buttons[0][0].getTicValue().equals(ticType)
				&& tttApplet.buttons[1][1].getTicValue().equals("")) {
			nextCellClick.x = 1;
			nextCellClick.y = 1;
		}

		// ==Checking right top to left bottom diagonal to put 3rd in a row

		if (tttApplet.buttons[0][2].getTicValue() == tttApplet.buttons[1][1].getTicValue()
				&& tttApplet.buttons[0][2].getTicValue().equals(ticType)
				&& tttApplet.buttons[2][0].getTicValue().equals("")) {
			nextCellClick.x = 2;
			nextCellClick.y = 0;
		}
		if (tttApplet.buttons[1][1].getTicValue() == tttApplet.buttons[2][0].getTicValue()
				&& tttApplet.buttons[1][1].getTicValue().equals(ticType)
				&& tttApplet.buttons[0][2].getTicValue().equals("")) {
			nextCellClick.x = 0;
			nextCellClick.y = 2;
		}
		if (tttApplet.buttons[0][2].getTicValue() == tttApplet.buttons[2][0].getTicValue()
				&& tttApplet.buttons[0][2].getTicValue().equals(ticType)
				&& tttApplet.buttons[1][1].getTicValue().equals("")) {
			nextCellClick.x = 1;
			nextCellClick.y = 1;
		}

		return nextCellClick;

	}

	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path, String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + imgURL);
			return null;
		}
	}
}
