
public class Order extends Data{
	void doSomething(){
		// Do something specific to Order processing
	}
}
