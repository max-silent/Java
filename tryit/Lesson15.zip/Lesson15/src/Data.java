
public abstract class Data {
	abstract void doSomething();
}
