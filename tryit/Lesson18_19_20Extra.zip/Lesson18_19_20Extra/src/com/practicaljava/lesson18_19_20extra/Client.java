package com.practicaljava.lesson18_19_20extra;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

    public static void main(java.lang.String[] args) {
        OutputStream outbound = null;
        BufferedReader inbound = null;
        Socket clientSocket = null;
        try {
            // Read Message from keyboard
            BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter message: ");
            String message = keyboard.readLine();

            // Open a client socket connection
            clientSocket = new Socket("localhost", 3000);
            System.out.println("Client: " + clientSocket);

            // Get the streams
            outbound = clientSocket.getOutputStream();
            inbound = new BufferedReader(new InputStreamReader(clientSocket.getInputStream(), "utf-8"));

            // Send message to the server
            outbound.write((message + "\n\n").getBytes("utf-8"));
            outbound.flush();

            // Receive response
            String response = inbound.readLine();
            System.out.println("Response: " + response);
        } catch (UnknownHostException uhe) {
            System.out.println("UnknownHostException: " + uhe);
        } catch (IOException ioe) {
            System.err.println("IOException: " + ioe);
        } finally {
            // Close the streams
            try {
                outbound.close();
                inbound.close();
                clientSocket.close();
            } catch(IOException e) {
                System.out.println("Can not close streams..." + e.getMessage());
            }
        }
    }

}
