package com.practicaljava.lesson18_19_20extra;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Date;
import java.util.concurrent.Callable;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.StringEscapeUtils;

public class MailCallable implements Callable<Object>, Constants {

    private Session session;
    private Socket client;

    public MailCallable(Session session, Socket client) {
        this.session = session;
        this.client = client;
    }

    @Override
    public Object call() throws Exception {
        BufferedReader inbound = null;
        OutputStream outbound = null;
        try {
            // Get the streams
            inbound = new BufferedReader(new InputStreamReader(client.getInputStream(), "utf-8"));
            outbound = client.getOutputStream();

            String clientIp = client.getRemoteSocketAddress().toString();

            String clientLine = inbound.readLine();
            clientLine = StringEscapeUtils.escapeHtml(clientLine);

            Message emailMessage = new MimeMessage(session);
            emailMessage.setFrom(new InternetAddress(EMAIL_SENDER_ADDRESS));
            emailMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(EMAIL_RECIPIENT_ADDRESS, false));
            emailMessage.setSubject(EMAIL_SUBJECT);
            emailMessage.setSentDate(new Date());
            emailMessage.setContent(String.format(EMAIL_TEXT, clientIp, clientLine), "text/html");
            Transport.send(emailMessage);

            // send confirmation
            outbound.write("Message has received. Wait a email.\n\n".getBytes("utf-8"));

            System.out.println("Email has sended.");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (outbound != null) {
                    outbound.flush();
                    outbound.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            try {
                if (inbound != null) {
                    inbound.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            try {
                if (client != null) {
                    client.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return null;
    }

}
