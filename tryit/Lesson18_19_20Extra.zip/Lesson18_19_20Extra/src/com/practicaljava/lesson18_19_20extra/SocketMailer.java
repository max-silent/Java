package com.practicaljava.lesson18_19_20extra;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.mail.Session;

public class SocketMailer implements Constants {

    public static void main(String[] args) {
        ServerSocket serverSocket = null;
        String password = null;

        try {
            if (args.length != 1){
                System.out.println("You may enter password when run program: java SocketMailer password");
                System.out.print("Enter email password: ");
                BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
                password = keyboard.readLine();
            } else {
                password = args[0];
            }

            Properties sessionProperties = new Properties();
            sessionProperties.put("mail.smtp.host", MAIL_SMTP_HOST);
            sessionProperties.put("mail.smtp.user", EMAIL_SENDER_ADDRESS);
            sessionProperties.put("mail.smtp.port", MAIL_SMTP_PORT);
            sessionProperties.put("mail.smtp.auth", "true");
            sessionProperties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            Session session = Session.getInstance(sessionProperties, new MailAuthenticator(password));

            ExecutorService executorService = Executors.newFixedThreadPool(10);

            // Create a server socket
            serverSocket = new ServerSocket(3000);

            System.out.println("Waiting for a requests");
            while (true) {
                // Wait for a request
                Socket client = serverSocket.accept();

                // Notify about client
                System.out.println("Client has connected " + client.getRemoteSocketAddress());

                executorService.submit(new MailCallable(session, client));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (serverSocket != null) {
                    serverSocket.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

}
