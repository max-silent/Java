package com.practicaljava.lesson18_19_20extra;

public interface Constants {

    public static final String EMAIL_SENDER_ADDRESS = "blabla.sender@gmail.com";

    public static final String EMAIL_RECIPIENT_ADDRESS = "blabla.group@googlegroups.com";

    public static final String MAIL_SMTP_HOST = "smtp.gmail.com";

    public static final String MAIL_SMTP_PORT = "465";

    public static final String EMAIL_SUBJECT = "SocketMailer over Thread";

    public static final String EMAIL_TEXT = "<html><body>"
        + "<b>RemoteSocketAddress:</b> %s<br/><br/>"
        + "<b>Message:</b><pre>%s</pre>"
        + "</body></html>";

}
