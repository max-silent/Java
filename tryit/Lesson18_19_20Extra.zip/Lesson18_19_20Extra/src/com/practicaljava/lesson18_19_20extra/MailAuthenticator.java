package com.practicaljava.lesson18_19_20extra;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class MailAuthenticator extends Authenticator implements Constants {

    private String password;

    public MailAuthenticator(String password) {
        this.password = password;
    }

    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication (EMAIL_SENDER_ADDRESS, password);
    }

}
