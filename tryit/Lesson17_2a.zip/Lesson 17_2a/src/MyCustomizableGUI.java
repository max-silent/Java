import javax.swing.*;

import java.awt.event.*;
import java.awt.*;

public class MyCustomizableGUI extends JPanel implements ActionListener{
	//private static final long serialVersionUID = -8402611325744957495L;
	private static final long serialVersionUID = 123L;
	//Main window declaration
	JFrame frame = new JFrame("My Text Editor");
	JTextField textField = new JTextField(20);
	JButton button = new JButton("Preferences");
	
	//UserPreferences dialog declaration
	UserPreferences preferences = new UserPreferences(this);
	MyCustomizableGUI(){
		//this.setLayout(null);
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.add(textField);
		this.add(button);
		frame.setContentPane(this);
		frame.pack();
		frame.setVisible(true);
		button.addActionListener(this);
		applyView();
		this.setVisible(true);
	}

	//Apply the preferences to this dialog's UI
	public void applyView() {
		if (preferences.getColor().equals("Red")) {
			textField.setForeground(Color.red);
		} else if (preferences.getColor().equals("Green")) {
			textField.setForeground(Color.green);
		} else if (preferences.getColor().equals("Blue")) {
			textField.setForeground(Color.blue);
		} else if (preferences.getColor().equals("Cyan")) {
			textField.setForeground(Color.cyan);
		} else if (preferences.getColor().equals("Magenta")) {
			textField.setForeground(Color.magenta);
		}else if (preferences.getColor().equals("Yellow")) {
			textField.setForeground(Color.yellow);
		}else if (preferences.getColor().equals("Black")) {
			textField.setForeground(Color.black);
		}
		textField.setFont(new Font(preferences.getFont(), Font.PLAIN, preferences.getFontSize()));
	}
	//Invoke the dialog for specifying UI preferences
	public void actionPerformed(ActionEvent e){ 
		//JOptionPane.showConfirmDialog(null,"Something happened...","Just a test",JOptionPane.PLAIN_MESSAGE);
		preferences.showPreferencesDialog(true);
		
	}

	public static void main(String[] args){
		new MyCustomizableGUI();
	}
}
