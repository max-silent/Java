It's just a text from LICENSE.md file.
