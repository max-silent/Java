# Java
This repository contains:
1. Folders with source files (src) and some prepared files (bin) related to the Java Applications and Applets
2. Folder with files (tryit) related to the "Try It" section of "Java Programming 24-Hour Trainer" by Yakov Fain.